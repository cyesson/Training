
############################################################
############################################################
### SPATIAL DATA TRAINING: PLOTTING ###
############################################################
############################################################

### META ###
# by HHakkinen
# Start Date: 04/11/2022
# End Date: 07/11/2022
# A training script for handling spatial data in R

# The following is split into several sections

# META: this is about the file itself, who made it, when, what does it do. 
#If relevant will also specify software or versions required to run it
#it might also detail what data is needed to run this file. In this case all data is self-contained



#SECTION 1: MAKING NICE PLOTS
# Some more fancy ways to plot data with different packages


### /META ###



#################################################
# SET-UP
#################################################


#this section just clears the R environment and loads packages. 


#keep env from previous scripts We need some of the info for this file
#rm(list=ls())


#packages for plotting
library(ggplot2)
library(RColorBrewer)
library(wesanderson)


#set the working directory. From now on this is the default location R will read and write files
#NOTE: you need to CHANGE THIS before the code will run. Customise to where you saved the "RSpatialTraining" folder
#also note if you use Windows then double check the path, windows likes to present paths weirdly. 
#the "/" symbol MUST be that way round.
setwd("C:/Users/Henry/Wherever/TheFolder/RSpatialTraining")




#################################################
#SECTION 4: PLOTTING
#################################################


### BASIC PLOTS

# we've done several simple plots already, but they are quite clumsy. What about fancy plots?
# customising a plot to be pretty is usually the last thing we do, 
# but sometimes to make patterns clearer we might want change colours/boundaries/scales etc. In which case we need to know how


#ggplot is great for fancy plotting, but has so many options it can be a bit confusing

ggplot(eurMapCrop) + 
  geom_sf() + 
  coord_sf()

#the first line here sets the "base" data and "aesthetics". eurMapCrop is our dataset
#in ggplot you then "add" to the base line, and add all the things you want to customise. 
#geom_sf() specifies we want to plot polygon data and use the "geometry" of our dataset
#coord_sf() specifies that this polygon data has coordinates and we want to plot it as a map, it also handles the projection


#here's a plot with colour
ggplot() + 
  geom_sf(data = eurMapCrop, mapping = aes(fill = id), show.legend = FALSE) +
  coord_sf()
#this time round we've specified we want to colour each polygon by id (a column in our dataset)

#let's add labels
ggplot(eurMapCrop) + 
  geom_sf(aes(fill = id), show.legend = FALSE) + 
  coord_sf() + 
  geom_sf_label(aes(label = CNTR_CODE), label.padding = unit(1, "mm"))
#we have now coloured each country by ID, and labelled each county by CNTR_CODE
#geom_sf_label() specifically adds labels to maps and polygons



#let's add points to our maps as well, we can use our june observations
spSfJune2
#also let's use a better projection
#eurMapTra2 is our transformed back with our Europe specific projection
ggplot() + 
  geom_sf(data = eurMapTra2) + 
  geom_sf(data = eurMapTra2, colour = "black", fill = "lightgreen") + 
  geom_sf(data = spSfJune2, colour = "red") + 
  coord_sf()


#when plotting we either rely on pre-made defaults (known as themes):
ggplot() + 
  geom_sf(data = eurMapTra2) + 
  coord_sf() +
  theme_minimal()
themes()
#see ?theme to look at all available themes

#OR we can specify options ourselves. This has more options but also needs more work
#For example, we can add various axes labels and titles. All are optional, but useful
ggplot() + 
  geom_sf(data = eurMapTra2) + 
  geom_sf(data = eurMapTra2, colour = "black", fill = "lightgreen") + 
  geom_sf(data = spSfJune2, colour = "red") + 
  #add the year observed
  geom_sf_text(mapping = aes(label=year), data = spSfJune2, nudge_x = -200000, nudge_y=00000, colour = "black", check_overlap=T) +
  coord_sf()+
  #add scale and arrow
  annotation_scale(location = "bl", width_hint = 0.5) +
  annotation_north_arrow(location = "bl", which_north = "true", 
                         pad_x = unit(0.75, "in"), pad_y = unit(0.5, "in"),
                         style = north_arrow_fancy_orienteering) +
  #we can also use themes as a shortcut. these are pre-designed
  theme_bw() +
  #we can also add titles
  ggtitle("Recorded observations of Manx Shearwater in June ", subtitle="2010-2015") +
  #and captions:
  labs(caption = "Based on data from EBBA2 breeding data, which in turn is based on terrestrial surveys")



####################################################
###PLOTTING RASTERS###
####################################################

#now let's plot our raster data
#we have a raster object called ukireRas, handled through stars, let's plot that
#it should be the environmental info for Uk and Ireland
ggplot() + 
  geom_stars(data = ukireRas) + 
  coord_equal()
#note coord_equal() is important for rasters. Because rasters are on a grid we have to make sure gpplot or R don't distort them
#coord_equal() ensures the grid is always regular and therefore accurate

#this works but looks pretty bad, let's tidy it up a bit


#WE can assigned custom colours for plots in R, aka colour palettes
#luckily a bunch of designers have done that already, I recommend the RColorBrewer and the Wes Anderson package

display.brewer.all()
names(wes_palettes)


#this is the same plot but with different colour schemes!
#plot with new colour gradient and a simpler theme
ggplot() + 
  geom_stars(data = ukireRas["MeanTemp_WM"]) + 
  coord_equal() +
  theme_minimal() +
  scale_fill_gradient(low="blue", high="red", na.value = 'NA')

#do it again with a new colour scheme from RColorBrewer (see display.brewer.all())
my.palette <- brewer.pal(n = 9, name = "YlOrRd")
ggplot() + 
  geom_stars(data = ukireRas["MeanTemp_WM"]) + 
  coord_equal() +
  theme_minimal() +
  scale_fill_gradientn(colors=my.palette, na.value = 'NA')

#do it again with a new colour scheme from Wes Anderson
ggplot() + 
  geom_stars(data = ukireRas["MeanTemp_WM"]) + 
  coord_equal() +
  theme_minimal() +
  scale_fill_gradientn(colors=wes_palette("Zissou1"), na.value = 'NA')


#more info on colours:
# https://www.nceas.ucsb.edu/sites/default/files/2020-04/colorPaletteCheatsheet.pdf
# https://github.com/karthik/wesanderson



### CHLOROPLETH MAPS
#let's make a map summarising how many manx shearwaters was spotted in each country
# many are off to sea so let's buffer that. If it occurred with a 100km of a country's coast line then it counts

#we will use spSfPnts, all observations between 2010-105
spSfPnts

#while sf is pretty good at working out errors, lat/long data are NOT GREAT for working out accurate distances etc.
#so we will reproject, safer than relying on sf to do all the work
spSfPntsRP<-st_transform(spSfPnts, st_crs(eurMapTra2))

#now buffer the points, remember distance is in meters
spSfRPBUF<-st_buffer(spSfPntsRP, dist=100000)


#check for intersections! what countries do these points overlap with (within 100km)?
spRes<-st_intersection(spSfRPBUF, eurMapTra2)

plot(spRes["id"], axes=T)


#each point here now has a country assigned to it, so we know which country is occurred in
#NOTE THAT IF a point occurs with 100km of e.g. UK and 100 km of Ireland it will be counted twice!
#not ideal and we should fix it, but leave it for now
#make a summary
table(spRes$id)
#save this table for later
tb1<-as.data.frame(table(spRes$id))
names(tb1)<-c("id", "NumObs")
tb1
#248 occurrences in France, 503 in Ireland, 33 in Iceland and 919 in the UK


#let's add a new column to our Europe map, one with "number of occurrences"
#we will "merge" our table into our map of Europe by the id column in both
eurRes<-merge(eurMapTra2, tb1, by="id")
plot(eurRes$geometry)

#note it has only kept the relevant parts of the map!
#to keep all of it:
eurRes<-merge(eurMapTra2, tb1, by="id", all.x=T)
plot(eurRes$geometry)

#much better

#now let's make a pretty plot
#GOING ALL OUT, so many things to customise

my.palette <- brewer.pal(n = 9, name = "Blues")

p <- ggplot() +
  
  #set basic data, it's a geom_sf() map, filled by number of observations, alpha adds a bit of transparancy
  geom_sf(data = eurRes, aes(fill = NumObs) , size=0, alpha=0.9) +
  
  #add simple theme
  theme_void() +
  
  # specify the colour palette and then loads of stuff on how we want the legend to look. Where the breaks are, what the orientation and size of the legend should be etc.
  scale_fill_gradientn(colors=my.palette, 
                       breaks=c(100,200,400,600,800), 
                       name="Number of Observations", 
                       guide = guide_legend( keyheight = unit(3, units = "mm"), keywidth=unit(12, units = "mm"), label.position = "bottom", title.position = 'top', nrow=1) ) +
  
  #I also want to add the raw observations!
  geom_sf(data = spSfPntsRP, colour = "red", size=0.01) +
  
  #now add details on titles and subttitles, equivalent to ggtitle() etc.
  labs(
    title = "Manx Shearwater Sightings",
    subtitle = "Number of Manx Shearwater Sightings within 100km of the Coast \n(2010-2015)",
    caption = "Data: EBBA2 | Creation: HHakkinen | Dummy Data"
  ) +
  
  #now we set very specific things. This is usually the LAST thing we do before publication or writing up, but here are some examples 
  #these all set colours, margins and size of text of everything
  theme(
    text = element_text(color = "#22211d"),
    plot.background = element_rect(fill = "#f5f5f2", color = NA),
    panel.background = element_rect(fill = "#f5f5f2", color = NA),
    legend.background = element_rect(fill = "#f5f5f2", color = NA),
    plot.title = element_text(size= 22, hjust=0.01, color = "#4e4d47", margin = margin(b = -0.1, t = 0.4, l = 2, unit = "cm")),
    plot.subtitle = element_text(size= 17, hjust=0.01, color = "#4e4d47", margin = margin(b = -0.1, t = 0.43, l = 2, unit = "cm")),
    plot.caption = element_text( size=12, color = "#4e4d47", margin = margin(b = 0.3, r=-99, unit = "cm") ),
    
    legend.position = c(0.8, 0.09)
  ) +
  coord_sf()

x11(width=12, height=8)
p


#lets save this plot for later!
ggsave("ManxSh_coolplot.png", p, dpi=300)



### EXERCISE (IF TIME) ###

#here is some sample data
tif <- system.file("tif/L7_ETMs.tif", package = "stars")
stars1 <- read_stars(tif)
stars2 = split(stars1, "band")

plot(stars2["X1"], axes=T)

#plot stars2["X1"] in colours with proper labels. Make it as elaborate as you like!







