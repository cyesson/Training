


### install required packages
install.packages("sf")
install.packages("stars")
install.packages("rworldmap")
install.packages("eurostat")
install.packages("terra")
install.packages("ggspatial")

install.packages("ggplot2")
install.packages("RColorBrewer")
install.packages("wesanderson")

#NOTE: if any packages ask you to install from source, select "No". 
#Selecting "Yes" can cause some installs to fail (especially on Mac OS)


### test all packages load correctly. Run the following and check there are no errors
library(sf)
library(stars)
library(rworldmap)
library(eurostat)
library(terra)
library(ggspatial)

#packages for plotting
library(ggplot2)
library(RColorBrewer)
library(wesanderson)
