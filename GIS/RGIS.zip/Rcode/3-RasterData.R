
############################################################
############################################################
### SPATIAL DATA TRAINING: WORKING WITH RASTER DATA ###
############################################################
############################################################

### META ###
# by HHakkinen
# Start Date: 04/11/2022
# End Date: 07/11/2022
# A training script for handling spatial data in R

# The following is split into several sections

# META: this is about the file itself, who made it, when, what does it do. 
#If relevant will also specify software or versions required to run it
#it might also detail what data is needed to run this file. In this case all data is self-contained


#SECTION 1: READING AND CHECKING DATA
# some examples of reading in different types of spatial data, checking it and some ways to fix common problems

#SECTION 2: WORKING WITH RASTER DATA
# some examples of manipulating RASTER data including cropping, aligning, reprojecting, buffering etc.



### /META ###



#################################################
# SET-UP
#################################################


#this section just clears the R environment and loads packages. 


#keep env from 2PolygonData. We need some of the info for this file
#rm(list=ls())


#load packages
#library(sf)
library(stars)
#library(rworldmap)
#library(eurostat)
library(terra)
library(ggspatial)



#set the working directory. From now on this is the default location R will read and write files
#NOTE: you need to CHANGE THIS before the code will run. Customise to where you saved the "RSpatialTraining" folder
#also note if you use Windows then double check the path, windows likes to present paths weirdly. 
#the "/" symbol MUST be that way round.
setwd("C:/Users/Henry/Wherever/TheFolder/RSpatialTraining")




#################################################
# READING AND CHECKING DATA
#################################################




### RASTER DATA ###

#rasters are grids of data. by default they have 1 layer of data, where each gridcell has one value
#but you also get 'stacks' or 'bricks' where there are multiple layers of data (aka 'bands')

#we want to load some environmental variables from across Europe
#we will use the "stars" package as it's more compatible with SF. 
#but you can do all of the below with the "raster" package instead


#this loads all layers in a stack
terrRas<-read_stars("Data/TerrEnvVariables_5m.tif")

#check raster file
terrRas
x11()
plot(terrRas)




#the "band" section is the part that actually has our information, this format is compact but not that useful at looking at information
#lets expand the compressed data so we can look at it

terrRasBig = split(terrRas, "band")
terrRasBig
#now we can see that 9 layers but annoyingly this file has lost its layer names. 
#Luckily I have a document reminding me what this is supposed to contain
#add layer names back manually
terrRasBig<-setNames(terrRasBig, c("MeanTemp_WM", "Prec_BreedMonths", "Isol", 
                                   "Area", "LandCover", "distToSea", "nearestSeaCell",
                                   "NDVI_mean", "NDVI_min"))

terrRasBig
#much better


#we don't need all these layers, we might as well lose some to save space
terrRas<-terrRasBig[c("MeanTemp_WM", "Prec_BreedMonths", "NDVI_mean")]


#check again
terrRas
class(terrRas)

#plot one layer 
plot(terrRas["MeanTemp_WM"], axes=T)


#we can also save raster data. We might want to do this later when we've done calculations
write_stars(terrRas, "Data/TEMPraster.tif", layer="MeanTemp_WM")



#we can do various functions with rasters
#the stars package actually has a lot of overlap with sf so many of the functions are the same
#one of its advantages!

#create a box with random dimensions so we can crop our raster
bb<-st_bbox(c(xmin=27, xmax=35, ymin=50, ymax=60),crs=st_crs(4326))
TestTmax<-st_crop(terrRas, bb)

write_stars(TestTmax, "Data/TESTcropraster.tif", layer="MeanTemp_WM")

#alternative way to save with more details on what to save
write_stars(obj=TestTmax,
            dsn="./Data/TESTcropraster.tif", 
            layer=1, 
            NA_value= FALSE, 
            update=F)




#we can also convert rasters into a different data class
terrAlt<-as(terrRas, "Raster")
class(terrAlt)
terrAltRas<-rast(terrAlt)
class(terrAltRas)
writeRaster(terrAltRas, "Data/TEMPraster2.tif",overwrite=TRUE)

#this can be very useful if one package has a specific function you need that other packages don't have!





#################################################
#SECTION 3: WORKING WITH RASTER DATA
#################################################

#rasters work a bit differently as they are grids, but they still have projections and many principles still apply
st_crs(terrRas)

st_crs(spPol)

#we can reproject the raster, let's say we wanted to use ETRS89-extended / LAEA Europe (EPSG 3035)
terrRasproj <- st_transform(terrRas,crs = "EPSG:3035")
st_crs(spPol)

#compare
x11()
plot(terrRas["MeanTemp_WM"], main="old projection", downsample=6)
x11()
plot(terrRasproj["MeanTemp_WM"], main="new projection", downsample=6)

#note: downsample is a useful argument, for high-resolution files, plotting can take ages
#downsample simplifies the raster to make it faster to plot. The higher the value the more it simplifies


#BE VERY CAREFUL when reprojecting rasters. Why might that be?





### EXTRACTING DATA

#let's say we want to know what the temperature is at a set of occurrence point
#we can use extract
tempvals<-st_extract(terrRas, spSfPnts)

#these are the values in the raster at each occurrence point
#we can even add these back to our point data
spSfPnts$temp<-tempvals$MeanTemp_WM
spSfPnts
#NA values mean the point is probably out to sea, so there's no terrestrial temperature

x11()
plot(eurMapCrop$geometry)
plot(spSfPnts["temp"],add=T)






### CROPPING AND MASKING FOR RASTERS

#let's say we are only interested in cells in a certain area (defined by a polygon)
#this is basically the same as cropping!
#let's say we wanted the climate variables for just UK and Ireland
eurMapUKIR<-eurMap[eurMap$id %in% c("IE", "UK"),]
plot(eurMapUKIR$geometry)

ukireRas<-st_crop(terrRas, eurMapUKIR)
#note that st_crop() will only work if both objects are in the same coordinate system
#in this case they are so we are fine
st_crs(terrRas)
st_crs(eurMapUKIR)

#if they are not then reproject them so they match
#as we said before reprojecting rasters is generally a bad idea
#so instead reproject the polygon to match the raster (if possible)

x11()
plot(ukireRas["MeanTemp_WM"])


#we can also mask rasters by value
r<-ukireRas["MeanTemp_WM"]
r[r < 14] <- NA
plot(r)

# working with rasters differs to working with sf polygons, but the principles are very similar
# most functions in sf for polygons have equivalent functions for rasters too, but they may have different names!
#list of common functions here: https://r-spatial.github.io/stars/articles/stars6.html



#### EXERCISE ####

#Practice with some other useful functions for rasters:

#1 what is the bounding box of ukireRas?

#2 create a new bounding box with xmin=-1, xmax=1, ymin=50, ymax=55

#3 crop ukireRas to the new bounding box

#4 what is the median temperature in this new cropped area?



