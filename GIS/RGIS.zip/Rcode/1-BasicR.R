
#Clear your previous work. Don't worry about this line yet, it just cleans up R's temp memory! Run it if you like
rm(list=ls())


##################################################################
#####################THINGS R CAN DO##############################
##################################################################


#Exercise 1:
#find the directory where you have saved this code file and adjust the line below accordingly:
setwd("C:/Users/xxx/xxxx/xxx/xxx/RGISworkshop/")


#R can do sums
2+2
2*5
2^8
2/4
pi*11.3



#you can 'save' values to use later.  <- means assign. Whatever is on the left is created, whatever on right is the value
#in the below example we 'create' an object called a and it was a value of 2
#note that is gets saved in your environment (see top right in RStudio). This is like a temporary memory of things that have been saved
a <- 2
print(a)
print(a+2)
#print() is a function. print() will print whatever is in the brackets. () brackets always refer to functions




#you can assign things other than numbers! Words have to be saved using quote marks ""
b <- "example"
print(b)
print(b+2) #note error



#in programming objects have a class. Think of it as a data type like in statistics (numerical, categorical etc.)
#items can be numeric, characters or combined. There are others, but we will cover those later
class(b)
class(a)



#you can create lists of numbers or words (i.e. lists of numeric values and character values)
list1 <- c(0,1,6,3,7,8)
print(list1)

list2 <- c("A","B","C","D","E","F")
print(list2)



#you can combine lists into a dataframe. 
#A dataframe has both rows and columns (two dimensions)
df1 <- data.frame(list1,list2)
colnames(df1)<-c("numFrogs","Pond")
print(df1)



#you can navigate a dataframe with subsetting. Some examples:
#select a columns with $
df1$numFrogs
#select a column with []. Square brackets always mean subset!
df1[, 1]
#select row 3, column 1
df1[3, 1]
#select row 1,2,3, column1
df1[1:3, 1]
#multiple rows 1,2,3, column1 by pi
pi * df1[1:3, 1]



#you can check values with logical checks
q <- 5

#does q equal exactly 5?
q == 5
#is q less than 5?
q < 5
#is q greater than 5?
q > 5



#the same thing can be done with characters
r <- "dog"
r == "dog"
r == "cat"



#you can search for values in a list or dataframe using logical checks
pet_list <- c("dog","dog","cat","frog","scorpion","dog","unicorn")
pet_list == "dog"
pet_list[pet_list == "dog"]




#making a fake data frame for later use
pet_list2 <- c("dog","cat","frog","scorpion","unicorn")
num2<-c(540,860,65,2,1000494)
df2 <- data.frame(pet_list2,num2)
colnames(df2)<-c("PetType","number")
df2

#I want to know what the median number of pets is!
median(df2$number)
#or the max
max(df2$number)

#I want to know how many pets were owned by more than 100 people
df2[df2$number > 100, ]




#you can read in data from other sources

#file called Example Farm.txt
#read in your datafile
farmDF<- read.table("Data/ExampleFarm.txt", header=T)

#you can view your data
View(farmDF)

#you can explore and plot your data
#histogram
hist(farmDF$Height)

#scatter plot
plot(farmDF$Height, farmDF$QualScore, col="blue")


#groups of data can have different classes two
class(farmDF)
#and data.frames can have different data classes within them
class(farmDF$site)
class(farmDF$Animal)




#### EXERCISE ####

#1) read in a data file about limpets named "Limpets_2018.txt". It's in the "Data" folder

#2) find all limpets from site R. Subset using the "RL" column (which specifies which site the limpet is from)

#3) what is the median diameter of limpets from site R?

#4) make a scatter plot of nndia (on the x axis) and dia ONLY with limpets from site R

#5) make a scatter plot where limpets from site R are in blue, and limpets from site L are in red.
#HINT: you can add points to an existing plot by using points()



