

############################################################
############################################################
### SPATIAL DATA TRAINING: WORKING WITH POLYGON DATA ###
############################################################
############################################################

### META ###
# by HHakkinen
# Start Date: 04/11/2022
# End Date: 07/11/2022
# A training script for handling spatial data in R

# The following is split into several sections

# META: this is about the file itself, who made it, when, what does it do. 
#If relevant will also specify software or versions required to run it
#it might also detail what data is needed to run this file. In this case all data is self-contained


#SECTION 1: READING AND CHECKING DATA
# some examples of reading in different types of spatial data, checking it and some ways to fix common problems

#SECTION 2: WORKING WITH SPATIAL POLYGON DATA
# some examples of manipulating POLYGON and POINT data including cropping, aligning, reprojecting, buffering etc.

### /META ###


#################################################
# SET-UP
#################################################



#this section just clears the R environment and loads packages. 


#clear env
rm(list=ls())


#load packages
library(sf)
#library(stars)
library(rworldmap)
library(eurostat)
#library(terra)
library(ggspatial)



#set the working directory. From now on this is the default location R will read and write files
#NOTE: you need to CHANGE THIS before the code will run. Customise to where you saved the "RSpatialTraining" folder
#also note if you use Windows then double check the path, windows likes to present paths weirdly. 
#the "/" symbol MUST be that way round.
setwd("C:/Users/Henry/Wherever/TheFolder/RSpatialTraining")




#################################################
# READING AND CHECKING DATA
#################################################


#here are some common types of spatial data and how to read them in


#Some important background:
#up until recently most people in R used the "raster" and "sp" package
#if you look for help online you may see these mentioned, especially in older forums

#In this tutorial I will use the sf and stars packages, which are more modern and much much faster
#I strongly recommend using the sf and stars packages but go with whatever works!






### BACKGROUND MAPS ###

#for plotting we often want a background map to keep context. R and some packages have plenty of options for this
#here is just one example
eurMap<-get_eurostat_geospatial(resolution = 10, 
                                nuts_level = 0, 
                                year = 2016,
                                make_valid=F)
#take a look
#eurMap
class(eurMap)
#top section is meta data about the object, it's a collection of polygons. 
#Each polygon is a "feature" and each feature has attributes, which are the inforantion about it (id, levl_code etc)
#if we just want to plot the shapes then plot the geometry and ignore the rest of the data
plot(eurMap$geometry)


#here is another option to get a nice map of Europe
newmap <- getMap(resolution = "low")
#subset to just get Europe
newmap <- newmap[which(newmap$REGION=="Europe"),]

#take a look
#newmap
plot(newmap)




#note that although these are both polygon dataframes, they have different classes!
class(eurMap)
class(newmap)
#eurMap has been handled by the sf package so is a sf spatial object
#newmap was handled by the sp package, and is a SpatialPolygonsDataFrame








#################################################
### READING POLYGON DATA ###
#################################################

#now let's get some actual data to work with

#polygon data
spPol<-st_read("Data/Cepphus grylle.shp")
# 'st_read' is from the SF package, it can handle several types of spatial data

#check the data
spPol
class(spPol)
#always check data has loaded correctly, does the bounding box look right, is the projection right?

# projected CRS is the projection and the coordinate reference system.
# The most famous CRS is latitude/longitude, but it's not a great system for working our distances and areas
#because 1 degree of latitude at the equator is NOT the same distance as in the Arctic

#hence we use different CRS and projections to get more accurate maps. Most only work accurately for a specified area
#ETRS89-extended / LAEA Europe is designed to work with Europe and nearby areas
#for this given area it is accurate for area and (mostly) distance.

#this also explains why the "bounding box" is in odd units. These are meters!

#take a look
plot(spPol)

#we can also save Polygon data. We might want to do this later when we've done calculations
st_write(spPol, "Data/TEMPpolygon.shp", append=F)






#################################################
### READING POINT DATA ###
#################################################


#Point data can be stored in a variety of ways, one common way is as coordinates in a data frame
spPnts<-read.csv("Data/Puffinus puffinus.csv")

#check the data
head(spPnts)
View(spPnts)
class(spPnts)


#quick reminder:
#you can navigate a dataframe with subsetting. Some examples:
#select a columns with $
spPnts$x
#select a column with []. Square brackets always mean subset!
spPnts[, 1]
#select row 3, column 1
spPnts[3, 1]
#select row 1,2,3, column1
spPnts[1:3, 1]
#multiple rows 1,2,3, column1 by pi
pi * spPnts[1:2, 1]








#spPnts is clearly lat/lon data but currently it's just a list of coordinates. This is ok but isn't always that useful
#for example if we want to work with fancy map projections or do calculations we may want to have this as something more explicit

#so convert to spatial points
#note we have to specify which columns have the coordinates in
spSfPnts<-st_as_sf(spPnts, coords=c("x","y"))

#check it!
spSfPnts
class(spSfPnts)




#the point data is now a spatially explicit object, but it has no projection information (CRS is NA)
#it's good practice to set this to avoid confusion later on
#since it's lat/lon data we know what it is so can set manually
#lat/lon uses EPSG:4326 - WGS 84, latitude/longitude coordinate system based on the Earth's center of mass, 
#used by the Global Positioning System among others

#there are many many projections and coordinate reference systems. 
#Basically lat/lon is useful and often the default, but generally bad for calculating distances, areas or angles as it distorts too much
#if you ever want to do any calculations about distance or area then use a specific projection for an area.
#no firm rule for this, check online sources for recommended "equal area" or "equidistant" projections for a given area

st_crs(spSfPnts)<-"EPSG:4326"
spSfPnts

#check conversion worked ok
plot(spPnts$x, spPnts$y, col="red")
plot(spSfPnts$geometry, add=T)

overlap<-st_intersection(spSfPnts, eurMap)
overlap

#they are identical, just in different formats!







#################################################
#SECTION 2: WORKING WITH POLYGON AND POINT DATA
#################################################


#There are loads of things we can do with spatial data
#here are just some examples





###CHECKING AND FIXING DATA

#spatial data (especially polygons) are prone to errors
#these are usually microscopic overlaps, or gaps or errors
#it's a good idea to check and fix anything, otherwise you'll get errors later like
#"Evaluation error: TopologyException: Input geom 1 is invalid: Self-intersection"


st_is_valid(eurMap)
#all fine (all are TRUE)
st_is_valid(spPol)
#not fine! (error)

#check why
st_is_valid(spPol, reason=T)
#there's a self intersection at point 5116042.82615238 6665386.5309317
#this is the top right corner of the map and probably there is a tiny overlap.
#let's fix this
spPol<-st_make_valid(spPol)

st_is_valid(spPol)
#all good now!






###CROPPING
#out background data is useful, but it looks a bit weird as the azores are still included
#we don't want these, so we can crop the map

eurMapCrop<-st_crop(eurMap, xmin=-25, ymin=30, xmax=50, ymax=72)
plot(eurMapCrop$geometry, axes=T)

#we can also crop by another shape, so they have the same extent (bounding box)
eurMapCrop2<-st_crop(eurMap, spPol)

#now we get an error "st_crs(x) == st_crs(y) is not TRUE"
#why is this?





###TRANSFORMING CRS
eurMapTra<-st_transform(eurMapCrop, "EPSG:3035")

#we can do this using a EPSG code. OR we can just transform one map to match the other
eurMapTra2<-st_transform(eurMapCrop, st_crs(spPol))
#st_crs() just retrieves the projection/co-ordinate system from the spPol object

#create the old and the new maps for comparison
x11()
par(mfrow=c(1,2))
plot(eurMapCrop$geometry, main="old projection", axes=T)
plot(eurMapTra2$geometry, main="new projection", axes=T)
#note the different units!

#this new eurMapTra2 map is based on the ETRS89-extended / LAEA Europe projection. 
#it is extremely accurate for area/angle/distance across Europe and nearby areas
#but rapidly gets distorted and inaccurate once outside of Europe







###FINDING OVERLAPS
#for polygons we might want to find overlapping bits only
mapOv<-st_intersection(eurMapTra2, spPol)
#mapOv are only the bits of Europe that overlap with our species data
plot(mapOv$geometry)


#finding where points are
#we might want to know what polygons our points data are in
#e.g. we want to know what countries our species occurs in during June

#first we have to clarify to R that we this column is dates
#specify this column is a date, with days then months then years
spSfPnts$DateTime<-as.Date(spSfPnts$DateTime,format='%d/%m/%Y')

#we can also create new columns
#let's create a new column with just Year. We might want to split the data by year later
#we use format() to pull out one part of the date
#then we use factor() to tell R this is a category not a numeric.
spSfPnts$year<-factor(format(spSfPnts$DateTime,'%Y'))
spSfPnts
#note we have a new column!

#so let's work through it. First get all points from June from all years
juneLocs<-format(spSfPnts$DateTime,"%m") == "06"
#juneLocs lists the rows where the month is 06 (June)

spSfJune<-spSfPnts[juneLocs,]
spSfJune
#spSfJune is now all our points from June




#now we can work out where they are
JunePols<-st_filter(spSfJune, eurMapTra2)
#oops same error again, convert coordinate system
spSfJune2<-st_transform(spSfJune, st_crs(eurMapTra2))
#try again!
JunePols<-st_filter(eurMapTra2, spSfJune2)

#JunePols is a list of all polygons with a point from June in
JunePols$NAME_LATN


#make a quick plot
x11()
plot(eurMapTra2$geometry)
plot(JunePols$geometry, add=T, col="pink")
plot(spSfJune2$geometry, add=T, col="red")


#note that Iceland is not highlighted as the points are offshore.
#if we want to add a bit of flexibility, we can ask which country has a point within at least 100km
#for this we use st_buffer(). It adds a zone around each point which is then considered for each calculation
#note that units for this CRS (ETRS89-extended / LAEA Europe) are meters. so we buffer by 100,000m
st_crs(spSfJune2)$units

spSfJune2Buff<-st_buffer(spSfJune2, dist=100000)
JunePols2<-st_filter(eurMapTra2, spSfJune2Buff)

#JunePols2 is a list of all polygons where a point from June occurs within at least 100km
JunePols2$NAME_LATN


x11()
plot(eurMapTra2$geometry)
plot(JunePols2$geometry, add=T, col="orange")
#pink is the buffer zone
plot(spSfJune2Buff$geometry, add=T, col="pink")
plot(spSfJune2$geometry, add=T, col="red")


#sf is very powerful and there are many many other things you can do with it.
#i'd recommend the cheatsheet https://github.com/rstudio/cheatsheets/blob/main/sf.pdf
#and googling. 





#### EXERCISE ####

#1) Find the centroids of all countries in Europe (using eurMapTra2 and st_centroid())

#2) plot all European countries and then add a dot showing their centroids for each country

#3)  what is the furthest distance between two centroids of European countries
#hint: use st_distance()



