# load libraries into R

# before you begin ensure you set the current directory to the data directory

# open the file AgeNicheCorrelation.R
# to get age to most recent common ancestor we need a phylogeny
# load in tree example tree file and turn into a chronogram
t<-read.nexus("YessonCulham2006Subtree.tre")

# this tree is not ultrametric, convert to ultrametric using rate smoothing
t.dated<-chronopl(t,age.min=20,lambda=1)

# plot the tree using the following command
plot(t.dated)
nodelabels() # add node numbers
axisPhylo() # add a scale axis

# this tree has 7 terminal taxa
# we must repeat the niche correlation analysis
species.models.no<-niche.overlap( c("Drosera_peltata", "Drosera_binata", "Drosera_gigantea", "Drosera_macrantha" , "Drosera_platypoda", "Drosera_rosulata", "Drosera_stolonifera"))

# now parse the tree and the niche overlap results to the final analysis
arc<-age.range.correlation(t.dated,species.models.no)

# plot the age to mrca and niche overlap

plot(arc$age.range.correlation, cex=2,pch=19)

# add node numbers and a regression text(arc$age.range.correlation, labels = labels(arc$age.range.correlation)[[1]],pos=4)
abline(arc$linear.regression$coefficients)

# display regression statistics
summary(arc$linear.regression)

# we can write results to a text file
write.table(arc$age.range.correlation, file="AgeNicheCorrelation.txt")
write.table(arc$sig, file="AgeNicheCorrelationModelStats.txt")


