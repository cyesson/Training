## load in the library for manipulating phylogenetic trees
library(ape)

## load a tree
tr<-read.nexus("Data/YessonCulham2006Subtree.tre")

## simple NPRS can be done with the chronogram command
tr.nprs<-chronogram(tr,scale=20)
layout(matrix(1:2, 1, 2, byrow = TRUE))
plot(tr)
title("The original tree")
plot(tr.nprs)
axisPhylo()
title("NPRS tree")

## Reference Sanderson, M. J. (1997) Molecular Biology and Evolution, 14, 1218-1231.

## other rate smoothing can be done in R too
## MPL rate smoothing has been applied successfully to large trees
## MPL provides explicit tests of deviation from a clock at each node
## as well as standard errors on the ages
## perform an MPL rate smoothing
tr.mpl <- chronoMPL(tr)

## find the root length by taking the maximum node depth
tr.mpl.root.length<-max(branching.times(tr.mpl))
## scale root to 20Ma
tr.mpl.root.calibration<-20/tr.mpl.root.length

## calibrate the tree to set the root to age 20Ma
tr.mpl$edge.length <- tr.mpl$edge.length * tr.mpl.root.calibration

## plot a tree with the results
layout(matrix(1:4, 2, 2, byrow = TRUE))
plot(tr)
title("The original tree")
plot(tr.mpl)
axisPhylo()
title("The dated MPL tree")
plot(tr)
nodelabels(round(attr(tr.mpl, "stderr")*20/max(tr.mpl$edge.length), 3))
title("The standard-errors")
plot(tr)
nodelabels(round(attr(tr.mpl, "Pval"), 3))
title("The tests")

## this is adapted from the example given in the chronoMPL help page
## Reference Britton, T., Oxelman, B., Vinnersten, A. and Bremer, K. (2002) Molecular Phylogenetics and Evolution, 24, 58-65.


## different methods give different dates
layout(matrix(1:2, 1, 2, byrow = TRUE))
plot(tr.nprs)
title("NPRS Tree")
nodelabels(branching.times(tr.nprs))
