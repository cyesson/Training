## Perform a niche correlation analysis on a set of projected niche models

# load libraries into R
library("phyloclim")
library("adehabitat")

# load in the niche projections for 3 Australian sundews
Drosera_peltata<-import.asc("Drosera_peltata.asc")
Drosera_gigantea<-import.asc("Drosera_gigantea.asc")
Drosera_binata<-import.asc("Drosera_binata.asc")

# We can look at any of these maps using the plot command # for example this will give you a rough grid of Australia, dark areas are stronger predictions
plot(Drosera_gigantea,col=(c(grey(c(0.67-seq(20)/30)))),main="D. gigantea")

# Use this line to perform the niche overlap analysis
niche.overlap(c("Drosera_binata","Drosera_gigantea","Drosera_peltata"))
# Note: niche.overlap() runs the analysis
# Note: the list() command converts the individual layers into a list of layers, which is the format required by the niche.overlap function.
