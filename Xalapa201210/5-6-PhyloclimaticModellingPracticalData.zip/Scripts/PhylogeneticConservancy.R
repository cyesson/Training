################################################################
# test for phylogenetic conservancy
# start by re-loading the species mins data from PhyloclimaticModel.R

################################################################
# extract from phyloclimaticmodel.R

require("adehabitat")
require("ape")
require("SDMTools")

# fetch environmental layers
# for now we will pick one layer
temp.mean<-import.asc("Climate/CRUCL1Present/Mean_temperature.asc")

# load species data
species.locs<-read.table("YessonCulham2006Localities.txt",sep="\t",col.names=c("ID","Name","Long","Lat"))

# extract environmental data for the species locations
species.environment<-cbind(species.locs,environment=extract.data(species.locs[,3:4],temp.mean))

# create a store for the min and max values for each species
species.mins<-vector()
species.maxs<-vector()

## fetch the phylogeny
t<-read.nexus("YessonCulham2006Subtree.tre")
t.dated<-chronopl(t,age.min=20, lambda=1)

# fetch the min/max/mean for each species
for(i in unique(t.dated$tip.label))
{
     mySubset<-subset(species.environment,Name==i)
     species.mins[i]<-min(mySubset$environment,na.rm=T)
     species.maxs[i]<-max(mySubset$environment,na.rm=T)
 }

# view the results
species.mins
species.maxs

## do ancestral state reconstruction with continuous characters
species.mins.ace<-ace(species.mins,t.dated,method="ML")

################################################################
# end of extract of PhyloclimaticModel.R

# create a place holder for the likelihood results
species.mins.random.likelihoods<-vector()

# make 100 randomised replicate analyses
for(i in seq(1,100))
{
    # copy species mins list
    species.mins.copy<-species.mins
    species.mins.random<-sample(species.mins)

    for(j in seq(length(species.mins)))
    {species.mins.copy[[j]]<-species.mins.random[[j]]}

    species.mins.ace.copy<-ace(species.mins.copy,t.dated,method="ML")
    species.mins.random.likelihoods<-c(species.mins.random.likelihoods,species.mins.ace.copy$loglik)

}
print(paste("observed",species.mins.ace$loglik))
print("expected")
quantile(species.mins.random.likelihoods, c(0.001,0.01,0.05,0.95,0.99,0.999))

# observed is between 0.05 and 0.95 interval, so there is no significant phylogenetic conservancy
