# Build a phyloclimatic model
require("adehabitat")
require("ape")
require("SDMTools")

# fetch environmental layers
# for now we will pick one layer
temp.mean<-import.asc("Climate/CRUCL1Present/Mean_temperature.asc")

# have a look at the data
plot(temp.mean)

# load species data
species.locs<-read.table("YessonCulham2006Localities.txt",sep="\t",col.names=c("ID","Name","Long","Lat"))

# extract environmental data for the species locations
species.environment<-cbind(species.locs,environment=extract.data(species.locs[,3:4],temp.mean))

# view a summary of the data
summary(species.environment)

## fetch the phylogeny
t<-read.nexus("YessonCulham2006Subtree.tre")
t.dated<-chronopl(t,lambda=1,age.min=20)

# create a store for the min and max values for each species
species.mins<-vector()
species.maxs<-vector()

# fetch the min/max/mean for each species
for(i in unique(t.dated$tip.label))
{
     mySubset<-subset(species.environment,Name==i)
     species.mins[i]<-min(mySubset$environment,na.rm=T)
     species.maxs[i]<-max(mySubset$environment,na.rm=T)
 }

# view the results
species.mins
species.maxs


## do ancestral state reconstruction with continuous characters
species.mins.ace<-ace(species.mins,t.dated,method="ML")

## look at values on tree
plot(t.dated)
tiplabels(round(species.mins,2),adj=1)
nodelabels(adj=2,font=3)
nodelabels(round(species.mins.ace$ace,2),adj=0,bg="yellow")
axisPhylo()

## we want to focus on node 10 as this lineage was around at 8Ma
## which is the date of our palaeo environmental layer
## the reconstructed value is 12.35 degrees C

## now get max value
species.maxs.ace<-ace(species.maxs,t.dated,method="ML")
plot(t.dated)
tiplabels(round(species.maxs,2),adj=1)
nodelabels(adj=2,font=3)
nodelabels(round(species.maxs.ace$ace,2),adj=0,bg="yellow")
axisPhylo()
## This time the max value is 21.47 degrees C

## Look at the area bounded by these values in the present climate
## reclassify map to 1 for within range and 0 for outside range
temp.mean.masked<-as.asc((temp.mean<21.47)*(temp.mean>12.35)*1,xll=-180,yll=-90)
plot(temp.mean.masked)

## Open the environmental layer for 8Ma
temp.mean.8ma<-import.asc("Data/Climate/Bridge8Ma/Mean_temperature.asc")
## reclassify map to 1 for within range and 0 for outside range
temp.mean.8ma.masked<-as.asc((temp.mean.8ma<21.47)*(temp.mean.8ma>12.35)*1,xll=-180,yll=-90)

## now look at the projected image
plot(temp.mean.8ma.masked)

## export to an ascii grid file
export.asc(temp.mean.8ma.masked,"Node10Temp.asc")


