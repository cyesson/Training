library(ape)

# Get a tree
T<-read.tree(text="((A:1,B:1):1,C:2);")

# Make a data set
M<-c(1,1,2)

# calculate niche overlap between species
TM <-ace(M,T)

# show tree
plot(T,show.tip.labels=F)

# add node labels
nodelabels(round(TM$ace,2))
tiplabels(M,adj=1)
